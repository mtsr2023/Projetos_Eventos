package ifal.edu.br.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.AcaoAutomatica;
import ifal.edu.br.ConexaoBD;
import ifal.edu.br.Evento;

public class AcaoAutomaticaDAO {

	 public void salvar(AcaoAutomatica acao) throws Exception {
	        String sql = "INSERT INTO ACAOAUTOMATICA(evento_id, tipo, destino, status, resultado) VALUES (?, ?, ?, ?, ?)";
	        try (Connection conn = ConexaoBD.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS)) {
	            stmt.setInt(1, acao.getEvento().getId());
	            stmt.setString(2, acao.getTipo());
	            stmt.setString(3, acao.getDestino());
	            stmt.setString(4, acao.getStatus());
	            stmt.setString(5, acao.getResultado());
	            stmt.executeUpdate();
	            
	          try(ResultSet rs=stmt.getGeneratedKeys()){
	        	  if(rs.next()) {
	        		  acao.setId(rs.getInt(1));
	        	  }
	          }
	            
	            
	        }
	    }

	    public List<AcaoAutomatica> listarTodos() throws Exception {
	        List<AcaoAutomatica> lista = new ArrayList<>();
	        String sql = "SELECT * FROM ACAOAUTOMATICA";
	        try (Connection conn = ConexaoBD.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);

	        		ResultSet rs = stmt.executeQuery()) {
	            while (rs.next()) {
	                AcaoAutomatica a = new AcaoAutomatica();
	                a.setId(rs.getInt("id"));
	              
	                a.setTipo(rs.getString("tipoAcao"));
	                a.setDestino(rs.getString("destino"));
	                a.setStatus(rs.getString("status"));
	                a.setResultado(rs.getString("resultado"));
	                Evento e=new Evento();
	                e.setId(rs.getInt("evento_id"));
	                a.setEvento(e);
	                lista.add(a);
	            }
	        }
	        return lista;
	
}}

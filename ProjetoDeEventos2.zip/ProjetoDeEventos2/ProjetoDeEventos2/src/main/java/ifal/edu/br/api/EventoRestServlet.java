package ifal.edu.br.api;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

import com.google.gson.Gson;

import ifal.edu.br.Evento;
import ifal.edu.br.DAO.EventoDAO;

/**
 * Servlet implementation class EventoRestServlet
 */
@WebServlet("/api/eventos/*")
public class EventoRestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Gson gson = new Gson();
@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("application/json;charset=UTF-8");

		try {
			EventoDAO dao = new EventoDAO();
			String pathInfo = request.getPathInfo();

			if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty()) {

				List<Evento> eventos = dao.listarTodos();
				response.getWriter().write(gson.toJson(eventos));
			} else {
				
				 String idStr = pathInfo.substring(1); // remove a barra inicial
	                if (idStr.isEmpty()) {
	                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	                    response.getWriter().write("{\"erro\":\"ID não fornecido\"}");
	                    return;
	                    
			}
	                int id = Integer.parseInt(idStr);
	                Evento evento = dao.buscarPorId(id);
	                
	                if (evento != null) {
	                    response.getWriter().write(gson.toJson(evento));
	                } else {
	                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	                    response.getWriter().write("{\"erro\":\"Evento não encontrado\"}");
	                }
	                
	                
	                
	                
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write("{\"erro\":\"Falha ao buscar evento\"}");
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			BufferedReader reader = request.getReader();
			Evento evento = gson.fromJson(reader, Evento.class);
			

			if(evento == null || evento.getTitulo() == null || evento.getDescricao() == null
					   || evento.getDataHora() == null || evento.getUsuario() == null || evento.getTipoEvento() == null){
					    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
					    response.getWriter().write("{\"erro\":\"JSON inválido ou campos obrigatórios faltando\"}");
					    return;
					}
			EventoDAO dao = new EventoDAO();
			dao.Salvar(evento);

			response.setContentType("application/json");
			response.setStatus(HttpServletResponse.SC_CREATED);
			response.getWriter().write(gson.toJson(evento));

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().write("{\"erro\":\"Erro ao criar evento\"}");
		}

	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String pathInfo = request.getPathInfo();
			if (pathInfo == null || pathInfo.equals("/")) {
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().write("{\"erro\":\"Informe o ID do evento na URL\"}");
				return;
			}

			int id = Integer.parseInt(pathInfo.substring(1));
			BufferedReader reader = request.getReader();
			Evento evento = gson.fromJson(reader, Evento.class);
			evento.setId(id);

			EventoDAO dao = new EventoDAO();
			dao.atualizar(evento);

			response.setContentType("application/json");
			response.getWriter().write(gson.toJson(evento));

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write("{\"erro\":\"Erro ao atualizar evento\"}");
		}

	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String pathInfo = request.getPathInfo();
			int id = Integer.parseInt(pathInfo.substring(1));

			EventoDAO dao = new EventoDAO();
			dao.excluir(id);

			response.setContentType("application/json");
			response.getWriter().write("{\"mensagem\":\"Evento excluído com sucesso\"}");

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write("{\"erro\":\"Erro ao excluir evento\"}");
		}
	}

}

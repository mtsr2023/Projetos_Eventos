package ifal.edu.br.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.ConexaoBD;
import ifal.edu.br.Evento;
import ifal.edu.br.TipoEvento;
import ifal.edu.br.Usuario;

public class EventoDAO {

	public void Salvar(Evento evento) throws Exception {
		String sql = "INSERT INTO Evento(titulo,descricao,datahora,usuario_id,tipoevento_id,status)VALUES(?,?,?,?,?,?)";
		try (Connection conn = ConexaoBD.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(1, evento.getTitulo());
			stmt.setString(2, evento.getDescricao());
			stmt.setString(3, evento.getDataHora());
			stmt.setInt(4, evento.getUsuario().getId());
			stmt.setInt(5, evento.getTipoEvento().getId());
			stmt.setString(6, evento.getStatus());
			stmt.executeUpdate();

			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					evento.setId(rs.getInt(1));
				}
			}

		}

	}

	public List<Evento> listarTodos() throws Exception {
		List<Evento> eventos = new ArrayList<>();
		String sql = "SELECT * FROM EVENTO";

		try (Connection conn = ConexaoBD.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				Evento e = new Evento();
				e.setId(rs.getInt("id"));
				e.setTitulo(rs.getString("titulo"));
				e.setDescricao(rs.getString("descricao"));
				e.setDataHora(rs.getString("datahora"));
				e.setStatus(rs.getString("status"));

				// Reconstruindo user pq o programa bvai procurar o objeto e so ira encontar
				// numeros
				Usuario u = new Usuario();
				u.setId(rs.getInt("usuario_id"));
				e.setUsuario(u);

				// Reconstruindo tipo de evento para noa dar erro na classe evento
				TipoEvento t = new TipoEvento();
				t.setId(rs.getInt("tipoevento_id"));

				e.setTipoEvento(t);

				eventos.add(e);
			}
		}

		return eventos;

	}

	public Evento buscarPorId(int id) {
		Evento evento = null;
		String sql = "SELECT * FROM Evento WHERE id = ?";

		try (Connection con = ConexaoBD.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					evento = new Evento();
					evento.setId(rs.getInt("id"));
					evento.setTitulo(rs.getString("titulo"));
					evento.setDescricao(rs.getString("descricao"));
					evento.setDataHora(rs.getString("datahora"));
					evento.setStatus(rs.getString("status"));

					Usuario usuario = new Usuario();
					usuario.setId(rs.getInt("usuario_id"));
					evento.setUsuario(usuario);

					TipoEvento tipoEvento = new TipoEvento();
					tipoEvento.setId(rs.getInt("tipoevento_id"));
					evento.setTipoEvento(tipoEvento);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return evento;
	}

	public void atualizar(Evento evento) {
		String sql = "UPDATE Evento SET titulo = ?, descricao = ?, datahora = ?, usuario_id = ?, tipoevento_id = ?, status = ? WHERE id = ?";

		try (Connection conn = ConexaoBD.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, evento.getTitulo());
			ps.setString(2, evento.getDescricao());
			ps.setString(3, evento.getDataHora());
			ps.setInt(4, evento.getUsuario().getId());
			ps.setInt(5, evento.getTipoEvento().getId());
			ps.setString(6, evento.getStatus());
			ps.setInt(7, evento.getId());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(int id) throws Exception {
		String sqlHistorico = "DELETE FROM HistoricoEventoAcao WHERE acao_id IN (SELECT id FROM AcaoAutomatica WHERE evento_id = ?)";
		String sqlAcoes = "DELETE FROM AcaoAutomatica WHERE evento_id = ?";
		String sql = "DELETE FROM Evento WHERE id = ?";

		try (Connection conn = ConexaoBD.getConnection()) {
			
			try (PreparedStatement stmt = conn.prepareStatement(sqlHistorico)) {
	            stmt.setInt(1, id);
	            stmt.executeUpdate();
	        }

			try (PreparedStatement stmt = conn.prepareStatement(sqlAcoes)) {
				stmt.setInt(1, id);
				stmt.executeUpdate();
			}

			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, id);
				stmt.executeUpdate();
			}

		
		} catch (Exception e) {
			e.printStackTrace();
			throw e; //
		}
	}
}

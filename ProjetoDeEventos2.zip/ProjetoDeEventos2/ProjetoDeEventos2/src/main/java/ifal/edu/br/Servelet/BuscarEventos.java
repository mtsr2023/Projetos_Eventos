package ifal.edu.br.Servelet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import ifal.edu.br.Evento;
import ifal.edu.br.DAO.EventoDAO;

/**
 * Servlet implementation class BuscarEventos
 */
@WebServlet("/BuscarEventos")
public class BuscarEventos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			EventoDAO eventoDAO = new EventoDAO();
			
			

			List<Evento> listaDeEventos = eventoDAO.listarTodos();

			request.setAttribute("eventos", listaDeEventos);

			RequestDispatcher dispatcher = request.getRequestDispatcher("ListarEventos.jsp");
			dispatcher.forward(request, response);
		
//			response.setContentType("application/json");
//	        response.setCharacterEncoding("UTF-8");
//
//	     
//	        String json = new com.google.gson.Gson().toJson(listaDeEventos);
//
//	        
//	        response.getWriter().write(json);

		} catch (Exception e) {
			System.err.println("Ocorreu um erro ao listar os eventos: " + e.getMessage());
			e.printStackTrace();

		}
	}
}

package ifal.edu.br.Servelet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import ifal.edu.br.Usuario;
import ifal.edu.br.DAO.UsuarioDAO;


@WebServlet("/BuscarUsuario")
public class BuscarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		String iduser=request.getParameter("idUsuario");
		
		try {
			int id =Integer.parseInt(iduser);
			Usuario u=new UsuarioDAO().buscarPorId(id);
			
			 out.println("<html><body>");
	           	
	            
	            if(u!=null) {
	            	out.println("<!DOCTYPE html>");
	            	out.println("<html lang='pt-br'>");
	            	out.println("<head>");
	            	out.println("<meta charset='UTF-8'>");
	            	out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
	            	out.println("<title>Dados do Usuário</title>");
	            	out.println("<style>");
	            	out.println("body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }");
	            	out.println(".card { background: #fff; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 350px; text-align: center; }");
	            	out.println(".card h2 { color: #333; margin-bottom: 20px; }");
	            	out.println(".info { text-align: left; margin-top: 10px; }");
	            	out.println(".info p { background: #f9fafc; padding: 10px; border-radius: 8px; margin: 8px 0; font-size: 15px; }");
	            	out.println(".info b { color: #007bff; }");
	            	out.println("a.botao { display: inline-block; margin-top: 20px; text-decoration: none; background: #007bff; color: #fff; padding: 10px 20px; border-radius: 8px; transition: 0.3s; }");
	            	out.println("a.botao:hover { background: #0056b3; }");
	            	out.println("</style>");
	            	out.println("</head>");
	            	out.println("<body>");
	            	out.println("<div class='card'>");
	            	out.println("<h2>Perfil do Usuário</h2>");
	            	out.println("<div class='info'>");
	            	out.println("<p><b>ID:</b> " + u.getId() + "</p>");
	            	out.println("<p><b>Nome:</b> " + u.getNome() + "</p>");
	            	out.println("<p><b>Email:</b> " + u.getEmail() + "</p>");
	            	out.println("</div>");
	            	out.println("<a href='HomePage.html' class='botao'>Voltar</a>");
	            	out.println("</div>");
	            	out.println("</body>");
	            	out.println("</html>");
	            } else {
	                out.println("<p>Usuário com ID " + id + " não encontrado.</p>");
	            }
	            
	            out.println("<a href='BuscarUsuario.html'>Voltar</a>");
	            out.println("</body></html>");
	            
			
		} catch (Exception e) {
		 e.printStackTrace();	// TODO: handle exception
		}
		
		
	}

}

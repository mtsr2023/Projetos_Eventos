package ifal.edu.br.Servelet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import ifal.edu.br.Evento;
import ifal.edu.br.DAO.EventoDAO;

/**
 * Servlet implementation class EdItarEvento
 */
@WebServlet("/EdItarEvento")
public class EdItarEvento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		   try {
	        
	            int id = Integer.parseInt(request.getParameter("id"));

	           
	            EventoDAO dao = new EventoDAO();
	            Evento evento = dao.buscarPorId(id);

	            if (evento != null) {
	             
	                request.setAttribute("evento", evento);
	                request.getRequestDispatcher("editarEvento.jsp").forward(request, response);
	            } else {
	               
	                response.sendRedirect("BuscarEventos");
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao carregar evento.");
	        }
		
		
		
		
	}

	

}

package ifal.edu.br;



public class HistoricoEventoAcao {

	private int id;
	private Evento evento;
	private AcaoAutomatica acao;
	private String dataHora;
	private String resultado;

	public int getID() {
		return id;
	}

	public void setID(int iD) {
		id = iD;
	}

	public Evento getEvento() {
		return evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public AcaoAutomatica getAcao() {
		return acao;
	}

	public void setAcao(AcaoAutomatica acao) {
		this.acao = acao;
	}

	public String getDataHora() {
		return dataHora;
	}

	public void setDataHora(String dataHora) {
		this.dataHora = dataHora;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

}

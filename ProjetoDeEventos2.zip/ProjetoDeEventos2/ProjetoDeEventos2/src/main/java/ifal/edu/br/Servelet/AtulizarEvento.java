package ifal.edu.br.Servelet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import ifal.edu.br.Evento;
import ifal.edu.br.DAO.EventoDAO;

/**
 * Servlet implementation class AtulizarEvento
 */
@WebServlet("/AtulizarEvento")
public class AtulizarEvento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		 try {
	            int id = Integer.parseInt(request.getParameter("id"));
	            String titulo = request.getParameter("titulo");
	            String descricao = request.getParameter("descricao");
	            String status = request.getParameter("status");
	            int tipoEventoId = Integer.parseInt(request.getParameter("tipoEventoId"));

	            EventoDAO dao = new EventoDAO();
	            Evento evento = dao.buscarPorId(id); 
	            evento.setTitulo(titulo);
	            evento.setDescricao(descricao);
	            evento.setStatus(status);
	            evento.getTipoEvento().setId(tipoEventoId);

	            dao.atualizar(evento); 
	            response.sendRedirect("BuscarEventos");
	        } catch (Exception e) {
	            e.printStackTrace();
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao atualizar evento.");
	        }
		
	}

}

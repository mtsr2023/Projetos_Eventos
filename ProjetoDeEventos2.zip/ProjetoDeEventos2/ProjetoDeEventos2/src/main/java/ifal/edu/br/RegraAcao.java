package ifal.edu.br;

public class RegraAcao {

	private int id;
	private TipoEvento tipoEvento;
	private AcaoAutomatica acao;
	private int prioridade;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public TipoEvento getTipoEvento() {
		return tipoEvento;
	}

	public void setTipoEvento(TipoEvento tipoEvento) {
		this.tipoEvento = tipoEvento;
	}

	public AcaoAutomatica getAcao() {
		return acao;
	}

	public void setAcao( AcaoAutomatica acao) {
		this.acao = acao;
	}

	public int getPrioridade() {
		return prioridade;
	}

	public void setPrioridade(int prioridade) {
		this.prioridade = prioridade;
	}

	

	
}

package ifal.edu.br.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.AcaoAutomatica;
import ifal.edu.br.ConexaoBD;
import ifal.edu.br.RegraAcao;
import ifal.edu.br.TipoEvento;


public class RegraAcaoDAO {


    public void salvar(RegraAcao regra) throws Exception {
        String sql = "INSERT INTO REGRAACAO(tipoevento_id, acao, prioridade) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, regra.getTipoEvento().getId());
            stmt.setInt(2, regra.getAcao().getId());
            stmt.setInt(3, regra.getPrioridade());
            stmt.executeUpdate();
            
            try(ResultSet rs=stmt.getGeneratedKeys()){
	        	  if(rs.next()) {
	        		  regra.setId(rs.getInt(1));
	        	  }
	          }
        }
    }

    public List<RegraAcao> listarTodos() throws Exception {
        List<RegraAcao> lista = new ArrayList<>();
        String sql = "SELECT * FROM REGRAACAO";
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                RegraAcao r = new RegraAcao();
                r.setId(rs.getInt("id"));
                
                r.setPrioridade(rs.getInt("prioridade"));
                TipoEvento tp= new TipoEvento();
	            tp.setId(rs.getInt("tipoevento_id"));
	            r.setTipoEvento(tp);
	             
	            AcaoAutomatica au=new AcaoAutomatica();
	            au.setId(rs.getInt("acao"));
	            r.setAcao(au);
	            
	            
	            
	            lista.add(r);
            }
        }
        return lista;
    }
    
    public RegraAcao buscarTipoEventoId(int tipoEventoId) throws Exception{
		
    	 String sql="SELECT * FROM REGRAACAO WHERE tipoevento_id=?";
    	 
    	 try(Connection conn=ConexaoBD.getConnection();
    		 PreparedStatement stmt=conn.prepareStatement(sql)){
    		 stmt.setInt(1, tipoEventoId);
    		 
    		 try(ResultSet rs=stmt.executeQuery()){
    			 if(rs.next()) {
    				 RegraAcao r=new RegraAcao();
    				 r.setId(rs.getInt("id"));
    				 r.setPrioridade(rs.getInt("prioridade"));
    				 
    				 AcaoAutomatica a= new AcaoAutomatica();
    				 a.setId(rs.getInt("acao"));
    				r.setAcao(a);
    				  	
    				TipoEvento t=new TipoEvento();
    				t.setId(rs.getInt("tipoevento_id"));
    				 
    				
    				return r;
    				 
    			 }
    		 }
    	 }
    	
    	
    	return null;
    	
    }
    
	
}

		package ifal.edu.br.DAO;
		
		
		
		import java.sql.Connection;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
	import java.util.ArrayList;
		import java.util.List;
		import ifal.edu.br.ConexaoBD;
		import ifal.edu.br.Usuario;
		
		public class UsuarioDAO {
		     
			public void Salvar(Usuario usuario) throws Exception{
				
				String sql="INSERT INTO Usuario(nome,email,senha)VALUES(?,?,?)";
				try(Connection conn=ConexaoBD.getConnection();
						PreparedStatement stmt=conn.prepareStatement(sql,java.sql.Statement.RETURN_GENERATED_KEYS)){
					   stmt.setString(1,  usuario.getNome());
					   stmt.setString(2, usuario.getEmail());
					   stmt.setString(3, usuario.getSenha());
					stmt.executeUpdate();
					
					
				 try(	ResultSet rs= stmt.getGeneratedKeys()){
					 if(rs.next()) {
						int idgerado=rs.getInt(1);
						usuario.setId(idgerado);
						
					 }
				 }
				} 	
			}
			
			  public List<Usuario > listar() throws Exception{
				  List<Usuario> usuarios=new ArrayList<>();
				  String sql=" SELECT * FROM Usuario";
				  
				  try(Connection conn =ConexaoBD.getConnection();
						  java.sql.Statement stmt=conn.createStatement();
						  ResultSet rs=stmt.executeQuery(sql))	{
					       while(rs.next()) {
					    	   Usuario  u=new Usuario();
					    	   u.setId(rs.getInt("id"));
					    	   u.setNome(rs.getString("nome"));
					    	   u.setEmail(rs.getString("email"));
					    	   u.setSenha(rs.getString("senha"));
					    	   usuarios.add(u);
					       }
				  }
				  
				  
				return usuarios ;
				  
			  }
			  
			  
			  public Usuario buscarPorId(int id )throws Exception{
				   String sql ="SELECT * FROM USUARIO WHERE ID=?";
				   Usuario user=null;
				   
				   try (Connection conn=ConexaoBD.getConnection();
						 PreparedStatement stmt=conn.prepareStatement(sql)){ 
					   
					   stmt.setInt(1, id);
					   
					   
					   try(ResultSet rs=stmt.executeQuery()){
						   if(rs.next()) {
							   user=new Usuario();
							   user.setId(rs.getInt("id"));
							   user.setNome(rs.getString("nome"));
							   user.setEmail(rs.getString("email"));
							   user.setSenha(rs.getString("senha"));
						   }
					   }
					   
				   }
					return user;
				
			  }
	
			
	
			
			  
		}

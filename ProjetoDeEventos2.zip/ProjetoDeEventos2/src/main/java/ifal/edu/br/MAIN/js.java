package ifal.edu.br.MAIN;

import java.util.List;

import ifal.edu.br.Evento;
import ifal.edu.br.DAO.EventoDAO;

public class js  {
   public static void main(String[] args) throws Exception {

EventoDAO dao = new EventoDAO();
       
       
       List<Evento> listaDeEventos = dao.listarTodos();
       
      
       if (listaDeEventos.isEmpty()) {
           System.out.println("Nenhum evento encontrado no banco de dados.");
       } else {
           System.out.println("--- LISTA DE EVENTOS ---");
          
           for (Evento evento : listaDeEventos) {
               // 4. Imprima os detalhes de cada evento
               System.out.println("ID: " + evento.getId());
               System.out.println("Título: " + evento.getTitulo());
               System.out.println("Descrição: " + evento.getDescricao());
               System.out.println("Data/Hora: " + evento.getDataHora());
               System.out.println("Status: " + evento.getStatus());
               System.out.println("ID do Usuário: " + evento.getUsuario().getId());
               System.out.println("ID do Tipo de Evento: " + evento.getTipoEvento().getId());
               System.out.println("--------------------------");
           }
       }
 
	   
	   
} 
}

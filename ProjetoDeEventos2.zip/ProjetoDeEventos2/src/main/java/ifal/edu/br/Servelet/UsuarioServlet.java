package ifal.edu.br.Servelet;

import java.io.IOException;
import java.io.PrintWriter;

import ifal.edu.br.Usuario;
import ifal.edu.br.DAO.UsuarioDAO;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
	    response.getWriter().println("Acesse este Servlet via formulário POST!");
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome=request.getParameter("nome");
		String email=request.getParameter("email");
		String senha=request.getParameter("senha");
		String opcao=request.getParameter("opcao");
		Usuario u=new Usuario();
		u.setNome(nome);
		u.setEmail(email);
        u.setSenha(senha);
        
        
     
     
       
        
        
       switch(opcao) {
	case "Cadastrar":
	    try {
	        new UsuarioDAO().Salvar(u);
	        
	        
	        
	        
	        
	        
	        HttpSession session=request.getSession();
	        session.setAttribute("usuarioLogado", u);
	        			
	        response.sendRedirect("HomePage.html");
	        
	       

	    } catch (Exception e) {
	        e.printStackTrace();
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<h2>Erro ao cadastrar usuário!</h2>");
	        out.println("<pre>");
	        e.printStackTrace(out);  
	        out.println("</pre>");
	    }
	    break;

        
        

       
       }
	}


	
}

package ifal.edu.br.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.AcaoAutomatica;
import ifal.edu.br.ConexaoBD;
import ifal.edu.br.Evento;
import ifal.edu.br.HistoricoEventoAcao;


public class HistoricoEventoAcaoDAO {
       
	 public void salvar(HistoricoEventoAcao hist) throws Exception {
	        String sql = "INSERT INTO HISTORICOEVENTOACAO(evento_id, acao_id, dataHora, resultado) VALUES (?, ?, ?, ?)";
	        try (Connection conn = ConexaoBD.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, hist.getEvento().getId());
	            stmt.setInt(2, hist.getAcao().getId());
	            stmt.setString(3, hist.getDataHora());
	            stmt.setString(4, hist.getResultado());
	            stmt.executeUpdate();
	            
	            try(ResultSet rs=stmt.getGeneratedKeys()){
		        	  if(rs.next()) {
		        		  hist.setID(rs.getInt(1));
		        	  }
		          }
	        }
	    }

	    public List<HistoricoEventoAcao> listarTodos() throws Exception {
	        List<HistoricoEventoAcao> lista = new ArrayList<>();
	        String sql = "SELECT * FROM HISTORICOEVENTOACAO";
	        try (Connection conn = ConexaoBD.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);
	             ResultSet rs = stmt.executeQuery()) {
	            while (rs.next()) {
	                HistoricoEventoAcao h = new HistoricoEventoAcao();
	                h.setID(rs.getInt("id"));              
	                h.setDataHora(rs.getString("dataHora"));
	                h.setResultado(rs.getString("resultado"));
	                   Evento e= new Evento();
	                   e.setId(rs.getInt("evento_id"));
	                   h.setEvento(e);
	                   
	                   AcaoAutomatica r=new AcaoAutomatica();
	                   r.setId(rs.getInt("acao_id"));
	                   h.setAcao(r);
	                   
	                lista.add(h);
	            }
	        }
	        return lista;
}}

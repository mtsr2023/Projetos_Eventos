package ifal.edu.br.DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.ConexaoBD;
import ifal.edu.br.Evento;
import ifal.edu.br.TipoEvento;
import ifal.edu.br.Usuario;

public class EventoDAO {

	public void Salvar(Evento evento) throws Exception{
		String sql="INSERT INTO Evento(titulo,descricao,datahora,usuario_id,tipoevento_id,status)VALUES(?,?,?,?,?,?)";
		    try(Connection conn=ConexaoBD.getConnection();
		    		PreparedStatement stmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
		    	stmt.setString(1, evento.getTitulo());
		    	stmt.setString(2, evento.getDescricao());
		    	stmt.setString(3, evento.getDataHora());
		    	stmt.setInt(4, evento.getUsuario().getId());
		    	stmt.setInt(5, evento.getTipoEvento().getId());
		    	stmt.setString(6, evento.getStatus());
		    	stmt.executeUpdate();
		    	
		    	 try(ResultSet rs=stmt.getGeneratedKeys()){
		        	  if(rs.next()) {
		        		  evento.setId(rs.getInt(1));
		        	  }
		          }
		    	
		    }
		
	}
	
	public List<Evento> listarTodos() throws Exception {
	    List<Evento> eventos = new ArrayList<>();
	    String sql = "SELECT * FROM EVENTO";

	    try (Connection conn = ConexaoBD.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            Evento e = new Evento();
	            e.setId(rs.getInt("id"));
	            e.setTitulo(rs.getString("titulo"));
	            e.setDescricao(rs.getString("descricao"));
	            e.setDataHora(rs.getString("datahora"));
	            e.setStatus(rs.getString("status"));

	            // Reconstruindo user pq o programa bvai procurar o objeto e so ira encontar numeros 
	            Usuario u = new Usuario();
	            u.setId(rs.getInt("usuario_id"));
	            e.setUsuario(u);
	            

	            // Reconstruindo tipo de evento para noa dar erro na classe evento 
	            TipoEvento t = new TipoEvento();
	            t.setId(rs.getInt("tipoevento_id"));
	          
	            e.setTipoEvento(t);

	            eventos.add(e);
	        }
	    }

	    return eventos;
	}
}

package ifal.edu.br;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBD {

	public static Connection getConnection() throws Exception {
		
		
	 Class.forName("org.h2.Driver");
		String url ="jdbc:h2:file:C:/Users/adrie/Documents/ProjetoEventos/h2-2024-08-11/h2/bin/meubd";
		String usuario = "sa";
		String senha = "";
		return DriverManager.getConnection(url, usuario, senha);

	}
}

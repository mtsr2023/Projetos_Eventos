package ifal.edu.br.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.ConexaoBD;
import ifal.edu.br.TipoEvento;


public class TipoEventoDAO {
   
	public void Salvar(TipoEvento tipoevento) throws Exception{
		
		String sql ="INSERT INTO TipoEvento(nome,descricao)VALUES(?,?)";
		try(Connection conn=ConexaoBD.getConnection();
				PreparedStatement stmt=conn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)){
			   stmt.setString(1,  tipoevento.getNome());
			   stmt.setString(2, tipoevento.getDescricao());
			  
			stmt.executeUpdate();
			
		try(ResultSet rs=stmt.getGeneratedKeys()){
			  if(rs.next()) {
				  tipoevento.setId(rs.getInt(1));
			  }
		}
			
		} 	
	}
	
	 public List<TipoEvento > listar() throws Exception{
		  List<TipoEvento> tipos=new ArrayList<>();
		  String sql=" SELECT * FROM TipoEvento";
		  
		  try(Connection conn =ConexaoBD.getConnection();
				  java.sql.Statement stmt=conn.createStatement();
				  ResultSet rs=stmt.executeQuery(sql))	{
			       while(rs.next()) {
			    	   TipoEvento  tp=new TipoEvento();
			    	   tp.setId(rs.getInt("id"));
			    	   tp.setNome(rs.getString("nome"));
			    	   tp.setDescricao(rs.getString("descricao"));
			    	
			    	   tipos.add(tp);
			       }
		  }
		  
		  
		return tipos ;
		  
	  }
	
	
	}
	


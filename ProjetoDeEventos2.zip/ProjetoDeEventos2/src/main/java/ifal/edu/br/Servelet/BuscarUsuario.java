package ifal.edu.br.Servelet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import ifal.edu.br.Usuario;
import ifal.edu.br.DAO.UsuarioDAO;


@WebServlet("/BuscarUsuario")
public class BuscarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		String iduser=request.getParameter("idUsuario");
		
		try {
			int id =Integer.parseInt(iduser);
			Usuario u=new UsuarioDAO().buscarPorId(id);
			
			 out.println("<html><body>");
	            out.println("<h1>Resultado da Busca</h1>");
	            
	            if(u!=null) {
	            	out.println("<p><b>ID:</b> " + u.getId() + "</p>");
	                out.println("<p><b>Nome:</b> " + u.getNome() + "</p>");
	                out.println("<p><b>Email:</b> " + u.getEmail() + "</p>");
	            } else {
	                out.println("<p>Usuário com ID " + id + " não encontrado.</p>");
	            }
	            
	            out.println("<a href='BuscarUsuario.html'>Voltar</a>");
	            out.println("</body></html>");
	            
			
		} catch (Exception e) {
		 e.printStackTrace();	// TODO: handle exception
		}
		
		
	}

}

package ifal.edu.br.Servelet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import ifal.edu.br.AcaoAutomatica;
import ifal.edu.br.Evento;
import ifal.edu.br.HistoricoEventoAcao;

import ifal.edu.br.TipoEvento;
import ifal.edu.br.Usuario;
import ifal.edu.br.DAO.AcaoAutomaticaDAO;
import ifal.edu.br.DAO.EventoDAO;
import ifal.edu.br.DAO.HistoricoEventoAcaoDAO;


@WebServlet("/EventoServlet")
public class EventoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			
			
			
			HttpSession session=request.getSession(false);

			if(session==null || session.getAttribute("usuarioLogado")==null) {
				response.sendRedirect("PaginaInicial");
				return;
			}
			
			Usuario usuarioQueEstaLogado=(Usuario) session.getAttribute("usuarioLogado");
			
			String titulo = request.getParameter("titulo");
			String descricao = request.getParameter("descricao");
			String status = request.getParameter("status");
			int tipoEventoId = Integer.parseInt(request.getParameter("tipoEventoId"));
			String dataHoraAtual = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			
			
			
			
			
			
			TipoEvento tipoOBJ = new TipoEvento();
			tipoOBJ.setId(tipoEventoId);

			

			Evento ev = new Evento();
			ev.setTitulo(titulo);
			ev.setDataHora(dataHoraAtual);
			ev.setStatus(status);
			ev.setTipoEvento(tipoOBJ);
			ev.setUsuario(usuarioQueEstaLogado);
			ev.setDescricao(descricao);

			EventoDAO event = new EventoDAO();
			event.Salvar(ev);

			AcaoAutomatica acaoHistorico = null;
   
			int acaoId=0;
			
			
			  
			  
			  
			  
			  
			  
			switch (tipoEventoId) {
			case 1:
				
                acaoId=1;
                acaoHistorico = new AcaoAutomatica();
				acaoHistorico.setDestino("Sistema de Tickets Interno");
				acaoHistorico.setTipo("Abrir Incidente Urgente");

				break;
			case 2:
				   acaoId=2;
				acaoHistorico = new AcaoAutomatica();
				acaoHistorico.setDestino("Em Sessão de Alerta");
				acaoHistorico.setTipo("Ativado o modo alerta");

				
				break;
			case 3:
				   acaoId=3;
				acaoHistorico = new AcaoAutomatica();
				acaoHistorico.setDestino("Home center Alert");
				acaoHistorico.setTipo("Ativado o modo aviso");
				

				break;
			case 4:
				   acaoId=4;
				acaoHistorico = new AcaoAutomatica();
				acaoHistorico.setDestino("/var/log/detailed_events.log");
				acaoHistorico.setTipo("Registrar o log detalhado ");
				
				

			default:
				break;
			}

			
			
			
			
			
			
			
			
			
			
			
			
			if (acaoHistorico != null) {

				String mesagemResultado = "Ação :" + acaoHistorico.getTipo() + " disparada automaticamente";

				acaoHistorico.setEvento(ev);
				acaoHistorico.setStatus(status);
				acaoHistorico.setResultado(mesagemResultado);

		
		
		
		   		AcaoAutomatica saveId=new AcaoAutomatica();
		   		saveId.setId(acaoId);
		   		
		   		AcaoAutomaticaDAO SalvarAcao = new AcaoAutomaticaDAO();
				SalvarAcao.salvar(acaoHistorico);
				
;   
				

				HistoricoEventoAcao historico = new HistoricoEventoAcao();
				historico.setAcao(saveId);
				historico.setDataHora(dataHoraAtual);
				historico.setEvento(ev);
				historico.setResultado(mesagemResultado);

				HistoricoEventoAcaoDAO salvarNoHistorico = new HistoricoEventoAcaoDAO();
				salvarNoHistorico.salvar(historico);
				
				
				
			}
			response.sendRedirect("HomePage.html");

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Ocorreu um erro interno.");
		}

	}

}
